public class Question8 {
        public static void main(String[] args) {
            int[] numbers = {11, 9, 88, 10,90,3,19};

            for (int i = 0; i < numbers.length; i++)
                System.out.println(numbers[i]);
        }
    }


