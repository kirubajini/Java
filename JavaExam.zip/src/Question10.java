public class Question10 {

        public static void main(String[] args) {

            System.out.println(" 1 ");
            System.out.println(" 22 ");
            System.out.println(" 333 ");
            System.out.println(" 4444 ");
        }
    }

