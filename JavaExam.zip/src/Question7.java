public class Question7 {
        public static void main(String[] args){

            int num=100;
            if(num % 2==0)
                System.out.println(num + "this is a even number");
            else
                System.out.println(num+"this is a Odd number");
        }
    }

