public class Question2 {
    public static void main(String[] args){
        String str ="Exercise";

        for (int Letter= str.length()-1; Letter>=0; Letter--){
            System.out.println(str.charAt(Letter));
        }

    }
}
