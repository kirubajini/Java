public class Question5 {

        public static void main(String args[]){
            System.out.println(Integer.toBinaryString(15));
            System.out.println(Integer.toBinaryString(40));
            System.out.println(Integer.toBinaryString(64));
        }

}
